

require('../phpMQTT.php');

$server = 'localhost';     
$port = 1883;                    
$username = '';                   
$password = '';                   
$client_id = 'phpMQTT-publisher'; 

$mqtt = new Bluerhinos\phpMQTT($server, $port, $client_id);

if ($mqtt->connect(true, NULL, $username, $password)) {
	$mqtt->publish('topicname/example', 'Hello!,0, false);
	$mqtt->close();
} else {
	echo "Time out!\n";
}