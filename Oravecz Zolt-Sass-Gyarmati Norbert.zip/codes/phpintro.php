<html>
    <head>
        <title>Pelda</title>
    </head>
    <body>
        <?php
            echo "Hello, egy PHP szkript vagyok!";
        ?>
    </body>
</html>