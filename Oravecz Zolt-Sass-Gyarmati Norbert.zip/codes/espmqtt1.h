void setup() {
  wifi.Connect();
  mqtt.Connect();
  client.onMessage(messageReceived); 
}
void loop() {
  mqtt.MQTTLoop();
  switch (function) {
    case x:
      //Do something...
      break;
    case y:
      //Do something...
      break;
  }
}

void messageReceived(String &topic, String &payload) {
  if (topic.equals("topicname")) {
    function = payload;
  }
}