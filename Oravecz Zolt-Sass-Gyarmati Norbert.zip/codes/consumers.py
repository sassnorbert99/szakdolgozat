
class House:
    def __init__(self):
        self.consume = 230
        self.daily = self.consume / 30


class FlatHouse:
    def __init__(self):
        self.consume = 200
        self.daily = self.consume / 30

