// Az osztaly inicializalasa datummal es koordinatakkal.
//A mai nappal, Parizs koordinataival
$sc = new AurorasLive\SunCalc(new DateTime(), 48.85, 2.35);


// A napfelkelte idopontjanak konvertalasa ora:perc formatumba.
$sunTimes = $sc->getSunTimes();
$sunriseStr = $sunTimes['sunrise']->format('H:i');

// A Nap poziciojanak kiolvasasa, a mai napi napfelkelte idejen
$sunrisePos = $sc->getPosition($sunTimes['sunrise']);

// Fokba torteno atkonvertalas
$sunriseAzimuth = $sunrisePos->azimuth * 180 / M_PI;